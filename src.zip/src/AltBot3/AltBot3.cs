using Robocode.TankRoyale.BotApi;

namespace TubesStima
{
    public class TankDiemBot : Bot
    {
        public static void Main(string[] args) => new TankDiemBot().Start();
        public TankDiemBot() : base(BotInfo.FromFile("AltBot3.json")) { }

        public override void Run()
        {
            // Hanya memutar radar, badan dan meriam tetap diam
            while (IsRunning)
            {
                TurnRadarRight(360);
            }
        }
    }
}